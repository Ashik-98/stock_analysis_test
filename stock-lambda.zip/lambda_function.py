import requests
import pandas as pd
import boto3
import io
from datetime import datetime
import consonants as con
import json

# AWS clients
s3_client = boto3.client("s3")
ssm = boto3.client("ssm")
sns = boto3.client("sns")

# S3 configuration
S3_BUCKET_NAME = "stockdev-6624"

# Success SNS notification
def send_sns_success(row_count):
    success_sns_arn = ssm.get_parameter(Name=con.SUCCESSNOTIFICATIONARN, WithDecryption=True)["Parameter"]["Value"]
    component_name = con.COMPONENT_NAME
    env = ssm.get_parameter(Name=con.ENVIRONMENT, WithDecryption=True)["Parameter"]["Value"]
    success_msg = con.SUCCESS_MSG + f" - File written successfully with the row_count of {row_count}"
    sns_message = f"{component_name} : {success_msg}"
    print(sns_message)
    succ_response = sns.publish(TargetArn=success_sns_arn, Message=json.dumps({"default": json.dumps(sns_message)}), Subject=env + " : " + component_name, MessageStructure="json")
    return succ_response

# Error SNS notification
def send_error_sns(msg):
    error_sns_arn = ssm.get_parameter(Name=con.ERRORNOTIFICATIONARN, WithDecryption=True)["Parameter"]["Value"]
    env = ssm.get_parameter(Name=con.ENVIRONMENT, WithDecryption=True)["Parameter"]["Value"]
    error_message = con.ERROR_MSG + " : " + msg
    component_name = con.COMPONENT_NAME
    sns_message = f"{component_name} : {error_message}"
    print(sns_message)
    err_response = sns.publish(TargetArn=error_sns_arn, Message=json.dumps({"default": json.dumps(sns_message)}), Subject=env + " : " + component_name, MessageStructure="json")
    return err_response

def lambda_handler(event, context):
    try:
        # raise Exception("TEST ERROR - SNS FAILURE NOTIFICATION") #for testing failure case in SNS

        # Get GitHub API URL from SSM
        github_api_url = ssm.get_parameter(Name=con.urlapi, WithDecryption=True)["Parameter"]["Value"]
        #print(github_api_url)

        # Generate S3 output path
        output_path = datetime.now().strftime("%d-%m-%Y/stock_data_%H:%M:%S.csv")

        # GitHub API request
        headers = {"User-Agent": "AWS-Lambda-Stock-Analysis"}
        response = requests.get(github_api_url, headers=headers)
        response.raise_for_status()
        files = response.json()

        # Get CSV files
        csv_files = [file["download_url"] for file in files if file["name"].endswith(".csv")]

        if not csv_files:
            raise Exception("No CSV files found in the repository.")

        # Remove the last CSV file and process it separately
        csv_file = csv_files.pop()
        d = pd.read_csv(csv_file)

        # Process remaining CSV files
        dataframes = []
        file_names = []

        for url in csv_files:
            file_name = url.split("/")[-1].replace(".csv", "")
            df = pd.read_csv(url)
            df["Symbol"] = file_name
            dataframes.append(df)
            file_names.append(file_name)

        # Combine DataFrames
        combined_df = pd.concat(dataframes, ignore_index=True)

        # Merge
        o_df = pd.merge(combined_df, d, on="Symbol", how="left")

        # Convert timestamp to datetime
        o_df["timestamp"] = pd.to_datetime(o_df["timestamp"])

        # Filter based on date
        filtered_df = o_df[(o_df["timestamp"] >= "2021-01-01") & (o_df["timestamp"] <= "2021-05-26")]

        # Group by Sector
        result_time = filtered_df.groupby("Sector").agg({
            "open": "mean",
            "close": "mean",
            "high": "max",
            "low": "min",
            "volume": "mean"
        }).reset_index()

        # Filter required sectors
        list_sector = ["TECHNOLOGY", "FINANCE"]
        result_time = result_time[result_time["Sector"].isin(list_sector)].reset_index(drop=True)

        # Convert DataFrame to CSV in memory
        csv_buffer = io.StringIO()
        result_time.to_csv(csv_buffer, index=False, header=True)

        # Write CSV to S3
        s3_client.put_object(Bucket=S3_BUCKET_NAME, Key=output_path, Body=csv_buffer.getvalue(), ContentType="text/csv")

        # Send success notification only after S3 upload succeeds
        print("Sending success notification")
        send_sns_success(len(result_time))

        return {
            "statusCode": 200,
            "body": f"Data processed and uploaded successfully to s3://{S3_BUCKET_NAME}/{output_path}"
        }

    except Exception as e:
        print(f"Error processing data: {str(e)}")
        print("Sending failure notification")
        send_error_sns(str(e))
        raise