import json
import requests
import pandas as pd
import boto3
from io import StringIO
from datetime import datetime
import consonants as con 

pd.set_option('display.max_columns', None)

# S3 client
s3 = boto3.client('s3')
ssm = boto3.client("ssm")
sns = boto3.client("sns")
response = ssm.get_parameter(
    Name="/stockurl",
    WithDecryption=True
)
github_api_url = ssm.get_parameter(Name=con.urlapi, WithDecryption=True)["Parameter"]["Value"]
# github_api_url = response["Parameter"]["Value"]
print(github_api_url)

# S3 bucket
BUCKET_NAME = "stockdev488"

def send_sns_success():
    success_sns_arn = ssm.get_parameter(Name=con.SUCCESSNOTIFICATIONARN, WithDecryption=True)["Parameter"]["Value"]
    component_name = con.COMPONENT_NAME
    env = ssm.get_parameter(Name=con.ENVIRONMENT, WithDecryption=True)['Parameter']['Value']
    success_msg = con.SUCCESS_MSG
    sns_message = (f"{component_name} :  {success_msg}")
    print(sns_message, 'text')
    succ_response = sns.publish(TargetArn=success_sns_arn,Message=json.dumps({'default': json.dumps(sns_message)}),
        Subject= env + " : " + component_name,MessageStructure="json")
    return succ_response
        
def send_error_sns(msg):
    error_sns_arn = ssm.get_parameter(Name=con.ERRORNOTIFICATIONARN)["Parameter"]["Value"]
    env = ssm.get_parameter(Name=con.ENVIRONMENT, WithDecryption=True)['Parameter']['Value']
    error_message=con.ERROR_MSG+msg
    component_name = con.COMPONENT_NAME
    sns_message = (f"{component_name} : {error_message}")
    err_response = sns.publish(TargetArn=error_sns_arn,Message=json.dumps({'default': json.dumps(sns_message)}),    Subject=env + " : " + component_name,
        MessageStructure="json")
    return err_response

def lambda_handler(event, context):

    # Create date and timestamp
    now = datetime.now()

    date_folder = now.strftime("%d-%m-%Y")
    timestamp = now.strftime("%H-%M-%S")

    # Create S3 file path
    S3_FILE_PATH = f"{date_folder}/stock_data_{timestamp}.csv"

    # GitHub API URL
    # github_api_url = "https://api.github.com/repos/squareshift/stock_analysis/contents/"

    # Get files from GitHub
    response = requests.get(github_api_url)
    response.raise_for_status()

    files = response.json()

    # Get only CSV files
    csv_files = [
        file['download_url']
        for file in files
        if file['name'].endswith('.csv')
    ]

    # Remove the last CSV file
    csv_file = csv_files.pop()

    # Read the removed CSV file
    d = pd.read_csv(csv_file)

    dataframes = []
    file_names = []

    # Read remaining CSV files
    for url in csv_files:

        file_name = url.split("/")[-1].replace(".csv", "")

        df = pd.read_csv(url)

        # Add stock symbol
        df['Symbol'] = file_name

        dataframes.append(df)
        file_names.append(file_name)

    # Combine all stock DataFrames
    combined_df = pd.concat(
        dataframes,
        ignore_index=True
    )

    # Merge with reference data
    o_df = pd.merge(
        combined_df,
        d,
        on='Symbol',
        how='left'
    )

    # Convert timestamp to datetime
    o_df["timestamp"] = pd.to_datetime(
        o_df["timestamp"]
    )

    # Filter date range
    filtered_df = o_df[
        (o_df['timestamp'] >= "2021-01-01") &
        (o_df['timestamp'] <= "2021-05-26")
    ]

    # Group by Sector
    result_time = (
        filtered_df
        .groupby("Sector")
        .agg({
            'open': 'mean',
            'close': 'mean',
            'high': 'max',
            'low': 'min',
            'volume': 'mean'
        })
        .reset_index()
    )

    # Filter required sectors
    list_sector = [
        "TECHNOLOGY",
        "FINANCE"
    ]

    result_time = result_time[
        result_time["Sector"].isin(list_sector)
    ].reset_index(drop=True)

    # Rename columns
    result_time.columns = [
        'Sector',
        'sector_open_mean',
        'sector_close_mean',
        'sector_high',
        'sector_low',
        'sector_volume_mean'
    ]

    # Convert DataFrame to CSV in memory
    csv_buffer = StringIO()

    result_time.to_csv(
        csv_buffer,
        index=False
    )

    # Upload CSV to S3
    s3.put_object(
        Bucket=BUCKET_NAME,
        Key=S3_FILE_PATH,
        Body=csv_buffer.getvalue(),
        ContentType='text/csv'
    )
    print("Sending the mail notification")
    send_sns_success()

    print("Data has been written successfully to S3")

    return {
        "statusCode": 200,
        "body": {
            "message": "Stock data processed successfully",
            "s3_bucket": BUCKET_NAME,
            "s3_file": S3_FILE_PATH,
            "records": len(result_time)
        }
    }

